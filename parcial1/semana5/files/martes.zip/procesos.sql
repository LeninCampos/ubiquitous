uso de stored procedures en mariadb

1.- Construye un SP que cree una etiqueta simple con el nombre del alumno

DELIMITER // 
CREATE PROCEDURE etiquetaAlumno()
BEGIN
    SELECT CONCAT('Alumno: ', nombre) AS Alumnos
    FROM Alumnos;
END // 
DELIMITER ;

2.- Construye un sp qeu utilice LA ETIQUETA LLAMADA MATRICULA ´EL NOMBRE DEL ALUMNO

DELIMITER $$ 
CREATE PROCEDURE matriculaAlumno()
BEGIN
SELECT CONCAT(matricula, ' - ', nombre) AS Alumnos
    FROM Alumnos;
END $$
DELIMITER ;

3.- Construye un SP que utilice una etiqueta llamada matricula + el nombre del alumno en mayusculas.

DELIMITER $$
CREATE PROCEDURE matriculaAlumnoM()
BEGIN
SELECT CONCAT(matricula, '-', UPPER(nombre)) AS Alumnos
    FROM Alumnos;
END $$
DELIMITER ;


-- Para llamar al procedimiento se usa CALL
-- Para ver procedimientos uso SHOW PROCEDURE STATUS WHERE Db='Biblioteca';
-- BORRAR DROP PROCEDURE nombre();

4.- Construye un email usando IN 

DELIMITER $$
CREATE PROCEDURE email_generado(
    IN dominio VARCHAR(100)
) 
BEGIN
    DECLARE dom VARCHAR(100);
    SET dom = dominio;


    SELECT nombre, 
        CONCAT(LOWER(REPLACE(nombre, ' ', ',')), '@',dom) AS email
        FROM Alumnos;

END $$ 
DELIMITER ;