INDICES en las bases de datos.

Un indice lo definimos como una estructura de datos que se crea de forma adicional a la tabla para permitir busquedas mas rapidas   

Funciona de manera similar al indice de un libro, en lugar de recorrer todo el documento, permite localizar directamente la informacion deseada     

Por lo que el uso comun de los indices es>
1.-Acelerar las consultas con WHERE
2.- Optimizar los JOIN
3.- Garantizar la unicidad (si es UNIQUE)
4.- Nos permite reducir el tiempo de busqueda en tablas grandes

CREATE INDEX indx_ ON Libros (autor);

SELECT id_libro, titulo, autor FROM Libros
    WHERE autor = 'Gabriel García Márquez';

ALTER TABLE Libros RENAME INDEX indx_ TO indx_libros_autor;

Existen diferentes tipos de indices, por ejemplo el INDICE COMPUESTO


CREATE INDEX indx_prestamos_matricula_fecha ON Prestamos (matricula, fecha_prestamo);

SELECT * FROM Prestamos 
    WHERE  matricula = 1005 AND fecha_prestamo >= '2024-08-01' ORDER BY fecha_prestamo;

Otro tipo de indice es el UNIQUE;

CREATE INDEX indx_alumnos_matricula ON Alumnos (matricula);

Para ver el uso del indice 

EXPLAIN SELECT * FROM Prestamos WHERE matricula = 1005;

Borra el indice 
DROP INDEX indx_alumnos_matricula ON Alumnos;

-------------

Stored Procedures
Simple procedimiento();
Con parametros procedimiento(param1, param2 ....);
SP con IN, OUT, indx_libros_autor

1.- Crea un SP que utilice IN, y que muestre los datos recibiendo como parametro el autor.

DELIMITER //
CREATE PROCEDURE autor(
    IN p_autor VARCHAR(100)
)
BEGIN
DECLARE t_autor VARCHAR(100);
SET t_autor = TRIM(p_autor);

SELECT id_libro, titulo, anio_publicacion
    FROM Libros
    WHERE autor = t_autor;

END //
DELIMITER ;

CALL autor('Gabriel García Márquez');

2.- Crea un SP que muestre los alumnos de un grado en particulas, utiliza IN para mandar el y verificar si el grado esta vacio, si lo esta, entonces que muestre un erro en pantalla.

DELIMITER //
CREATE PROCEDURE alumnosGrado(
IN p_grado VARCHAR(50)
)
BEGIN
 IF p_grado IS NULL OR TRIM(p_grado) = '' THEN
    SELECT 'ERROR: No mandaste el parametro' AS Error;

    ELSE
    SELECT matricula, nombre FROM Alumnos
        WHERE grado = p_grado;
END IF;

END // 
DELIMITER ;


CALL alumnosGrado('3° Secundaria');