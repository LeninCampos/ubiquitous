ordenes = (id_orden, fecha, id_cliente) clientes = (id_cliente, nom_cliente, id_estado) estados = (id_estado, estado) articulos_ordenes = (id_orden, num_item, cant) articulos = (num_item, desc_item, precio) CREATE TABLE tienda;

GRANT ALL PRIVILEGES ON tienda.* TO tienda_user_user @localhost IDENTIFIED BY FLUSH PRIVILEGES;

USE tienda;

CREATE TABLE articulos(
    num_item int(20) primary key,
    desc_item varchar(100) not null,
    precio float(10, 2) not null,
);

CREATE TABLE estados(
    id_estado int primary key auto_increment,
    estado char(150) not null
);

CREATE TABLE clientes(
    id_cliente int primary key,
    nom_cliente varchar(100),
    id_estado int not null,
    FOREIGN KEY(id_estado) REFERENCES estados (id_estado)
);

CREATE TABLE ordenes(
    id_orden int primary key,
    fecha date not null,
    id_cliente int not null,
    FOREIGN KEY(id_cliente) REFERENCES clientes(id_cliente)
);

CREATE TABLE articulos_ordenes(
    id_orden int not null,
    num_item int not null,
    PRIMARY KEY(id_orden, num_item),
    FOREIGN KEY(id_orden) REFERENCES ordenes(id_orden),
    FOREIGN KEY(num_item) REFERENCES articulos(num_item)
);