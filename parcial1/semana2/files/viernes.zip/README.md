# Gestión de Usuarios en MariaDB
**Autor:** Lenin Campos
**Materia:** Bases de Datos Avanzadas
**Fecha:** 23 de Enero, 2026

## 1. Descripción
Este ejercicio práctico tiene como objetivo la administración básica de un Sistema Gestor de Bases de Datos (DBMS) MariaDB alojado en una Máquina Virtual de Google Cloud. Se abarcan temas de seguridad inicial, creación de usuarios con privilegios específicos (DCL), creación de bases de datos (DDL) y generación de respaldos (Backups).

## 2. Requisitos Previos
* Instancia de VM en Google Cloud activa.
* MariaDB Server instalado y ejecutándose.
* Acceso `root` o `sudo` en el servidor.

## 3. Procedimiento y Comandos

### A. Configuración de Seguridad Inicial
Antes de crear usuarios, se ejecutó el script de seguridad para remover accesos anónimos y establecer la contraseña root del motor de base de datos.

```bash
# En terminal Linux:
sudo mariadb_secure_installation

# 1. Acceder al monitor de MariaDB como root
mysql -u root -p

-- Crear la base de datos
CREATE DATABASE Biblioteca;

GRANT ALL PRIVILEGES ON Biblioteca.* TO 'biblio_user'@'localhost' IDENTIFIED BY '666';

-- Aplicar cambios de privilegios
FLUSH PRIVILEGES;

EXIT;

# Acceder como el usuario específico
mysql -u biblio_user -p

mysqldump -u biblio_user -p Biblioteca > respaldo_biblioteca.sql

# Verificación del contenido del archivo generado
more respaldo_biblioteca.sql