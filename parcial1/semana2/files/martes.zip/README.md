# Reporte Sesión 1: Configuración de Entornos
**Autor:** Lenin Campos
**Materia:** Bases de Datos Avanzadas
**Fecha:** 20 de Enero, 2026

## 1. Descripción del Entregable
Este archivo documenta los procedimientos realizados en dos entornos distintos:
1.  **Servidor Ubiquitous:** Despliegue del portafolio web académico mediante acceso SSH/SFTP.

2.  **Google Cloud:** Creación de una Máquina Virtual (VM) e instalación del gestor de base de datos MariaDB.

## 2. Entorno 1: Google Cloud
En esta instancia se realizó la instalación y configuración técnica del DBMS.

### Requisitos
* Instancia VM (Compute Engine) con SO Linux (CentOS).
* Acceso root o sudo.

### Comandos de Instalación Ejecutados
A continuación, los comandos utilizados para levantar el servicio MariaDB:

sudo apt update

sudo apt install mariadb-server -y

sudo systemctl enable mariadb

sudo systemctl start mariadb

sudo systemctl status mariadb

3. **Entorno 2: Ubiquitous**

* Actuacomo host para los reportes de los ejercicios guiados

* Gestion de archivos con CyberDuck

* Subir pagina con index.html, css y js para visualizar la pagina en vez del indice


